IPython `pdb`
=============

.. image:: https://travis-ci.org/gotcha/ipdb.png?branch=master
  :target: https://travis-ci.org/gotcha/ipdb

Use
---

ipdb exports functions to access the IPython_ debugger, which features
tab completion, syntax highlighting, better tracebacks, better introspection
with the same interface as the `pdb` module.

Example usage:

.. code-block:: python

        import ipdb
        ipdb.set_trace()
        ipdb.set_trace(context=5)  # will show five lines of code
                                   # instead of the default three lines
        ipdb.pm()
        ipdb.run('x[0] = 3')
        result = ipdb.runcall(function, arg0, arg1, kwarg='foo')
        result = ipdb.runeval('f(1,2) - 3')

The post-mortem function, ``ipdb.pm()``, is equivalent to the magic function
``%debug``.

.. _IPython: http://ipython.org

If you install ``ipdb`` with a tool which supports ``setuptools`` entry points,
an ``ipdb`` script is made for you. You can use it to debug your python 2 scripts like

::

        $ bin/ipdb mymodule.py

And for python 3

::

        $ bin/ipdb3 mymodule.py

Alternatively with Python 2.7 only, you can also use

::

        $ python -m ipdb mymodule.py

You can also enclose code with the ``with`` statement to launch ipdb if an exception is raised:

.. code-block:: python

        from ipdb import launch_ipdb_on_exception

        with launch_ipdb_on_exception():
            [...]

.. warning::
   Context managers were introduced in Python 2.5.
   Adding a context manager implies dropping Python 2.4 support.
   Use ``ipdb==0.6`` with 2.4.

.. warning::
   Using ``from future import print_function`` for Python 3 compat implies dropping Python 2.5 support.
   Use ``ipdb<=0.8`` with 2.5.

Issues with ``stdout``
----------------------

Some tools, like ``nose`` fiddle with ``stdout``.

Until ``ipdb==0.9.4``, we tried to guess when we should also
fiddle with ``stdout`` to support those tools.
However, all strategies tried until 0.9.4 have proven brittle.

If you use ``nose`` or another tool that fiddles with ``stdout``, you should
explicitely ask for ``stdout`` fiddling by using ``ipdb`` like this

.. code-block:: python

        import ipdb
        ipdb.sset_trace()
        ipdb.spm()

        from ipdb import slaunch_ipdb_on_exception
        with slaunch_ipdb_on_exception():
            [...]


Development
-----------

``ipdb`` source code and tracker are at https://github.com/gotcha/ipdb.

Pull requests should take care of updating the changelog ``HISTORY.txt``.

Third-party support
-------------------

Products.PDBDebugMode
+++++++++++++++++++++

Zope2 Products.PDBDebugMode_ uses ``ipdb``, if available, in place of ``pdb``.

.. _Products.PDBDebugMode: http://pypi.python.org/pypi/Products.PDBDebugMode

iw.debug
++++++++

iw.debug_ allows you to trigger an ``ipdb`` debugger on any published object
of a Zope2 application.

.. _iw.debug: http://pypi.python.org/pypi/iw.debug

ipdbplugin
++++++++++

ipdbplugin_ is a nose_ test runner plugin that also uses the IPython debugger
instead of ``pdb``. (It does not depend on ``ipdb`` anymore).

.. _ipdbplugin: http://pypi.python.org/pypi/ipdbplugin
.. _nose: http://readthedocs.org/docs/nose


Changelog
=========

0.10.1 (2016-06-14)
-------------------

- Support IPython 5.0.
  [ngoldbaum]


0.10.0 (2016-04-29)
-------------------

- Stop trying to magically guess when stdout needs to be captured.
  Like needed by `nose`.
  Rather, provide a set of function that can be called explicitely when needed.
  [gotcha]

- drop support of IPython before 0.10.2


0.9.4 (2016-04-29)
------------------

- Fix Restart error when using `python -m ipdb`
  Closes https://github.com/gotcha/ipdb/issues/93.
  [gotcha]


0.9.3 (2016-04-15)
------------------

- Don't require users to pass a traceback to post_mortem.
  [Wilfred]


0.9.2 (2016-04-15)
------------------

- Closes https://github.com/gotcha/ipdb/issues/93.
  [gotcha]


0.9.1 (2016-04-12)
------------------

- Reset ``sys.modules['__main__']`` to original value.
  Closes https://github.com/gotcha/ipdb/issues/85
  [gotcha]

- Fix support of IPython versions 0.x
  [asivokon]


0.9.0 (2016-02-22)
------------------

- Switch to revised BSD license (with approval of all contributors).
  Closes https://github.com/gotcha/ipdb/issues/68
  [lebedov, gotcha]

0.8.3 (2016-02-17)
------------------

- Don't pass sys.argv to IPython for configuration.
  [emulbreh]


0.8.2 (2016-02-15)
------------------

- Fix lexical comparison for version numbers.
  [sas23]

- Allow configuring how many lines of code context are displayed
  by `set_trace`
  [JamshedVesuna]

- If an instance of IPython is already running its configuration will be
  loaded.
  [IxDay]


0.8.1 (2015-06-03)
------------------

- Make Nose support less invasive.
  Closes https://github.com/gotcha/ipdb/issues/52
  Closes https://github.com/gotcha/ipdb/issues/31
  [blink1073, gotcha]

- Fix for post_mortem in context manager.
  Closes https://github.com/gotcha/ipdb/issues/20
  [omergertel]


0.8 (2013-09-19)
----------------

- More Python 3 compatibility; implies dropping Python 2.5 support.
  Closes https://github.com/gotcha/ipdb/issues/37
  [gotcha]


0.7.1 (2013-09-19)
------------------

- IPython 1.0 compatibility.
  Closes https://github.com/gotcha/ipdb/issues/44
  [pgularski]

- Index into version_info in setup.py for Python 2.6 compatibility.
  [kynan]

- Add Travis CI configuration.
  [kynan]

0.7 (2012-07-06)
----------------

- Add ``launch_ipdb_on_exception`` context manager. Implies dropping Python 2.4 support.
  [Psycojoker]

- Wrap sys.excepthook only once.
  [marciomazza]

- Add GPL file and refer in headers.
  [stan3]

- Python 3 support.
  [Piet Delport]

- Basic tests.
  [msabramo]

- Added the functions ``runcall``, ``runeval`` and ``run``.
  [dimasad]


0.6.1 (2011-10-17)
------------------

- State dependency on IPython later or equal to 0.10.
  [gotcha]


0.6 (2011-09-01)
----------------

- Add setuptools ``console_scripts`` entry point.
  [akrito, gotcha] 

- Nose support.
  Closes https://github.com/gotcha/ipdb/issues/8
  [akaihola, gotcha]


0.5 (2011-08-05)
----------------

- IPython 0.11 support.
  [lebedov]


0.4 (2011-06-13)
----------------

- When used from IPython, use its colors.
  Closes https://github.com/gotcha/ipdb/issues/1
  [gotcha]

- Fixed errors when exiting with "q". 
  [gotcha]

- Allow use of ``python -m ipdb mymodule.py``.
  Python 2.7 only. 
  Closes https://github.com/gotcha/ipdb/issues/3 
  [gotcha]

- Fixed post_mortem when the traceback is None.
  [maurits]


0.3 (2011-01-16)
----------------

- Add ``post_mortem()`` for ``Products.PDBDebugMode`` support.
  [Jean Jordaan]

- Moved to github.com.


0.2 (2010-10-20)
----------------

- Added ``pm()``.
  [Paulo Benedict Ang]


0.1 (2010-04-26)
----------------

- First "non dev" release.


