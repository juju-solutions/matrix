
urwid-ubuntu
============

Ubuntu styled widgets for urwid.


