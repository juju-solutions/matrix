class RuntimeTypeError(Exception):
    pass
