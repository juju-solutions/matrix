from warnings import warn

warn("IPython.utils.localinterfaces has moved to jupyter_client.localinterfaces")

from jupyter_client.localinterfaces import *
