from __future__ import print_function
x = 1
print('x is:',x)
