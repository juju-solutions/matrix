=============================
theblues
=============================

Python library for using the juju charmstore API.

Installation
------------
The easiest way to install theblues is via pip::

    $ pip install theblues

Parts of theblues require the use of macaroons (e.g. parsing the return of
`Charmstore.fetch_macaroon` or interacting with `IdentityManager.discharge`).

To use authenticated aspects of theblues, e.g. JIMM, you'll need to be able to
manage macaroons. theblues was developed around libmacaroons. On ubuntu, you
can get libmacaroons from a ppa::


	$ sudo add-apt-repository ppa:yellow/ppa -y
	$ apt-get install libmacaroons0 python-macaroons libsodium13

Without these, theblues cannot make any authenticated requests to the
charm store or other services, but is usable to communicate with the charm
store for things like looking up charm information.

Usage
-----

Interacting with the charmstore is pretty simple. To look up an entity on the
charmstore (e.g. a charm or bundle)::

    >>> from theblues.charmstore import CharmStore
    >>> cs = CharmStore('https://api.jujucharms.com/v4')
    >>> entity = cs.entity('wordpress')
    >>> entity['Id']
    u'cs:trusty/wordpress-2'

Data for an entity is contained in the `Meta` item of the response, matching the
json returned from the charmstores::

    >>> entity['Meta']['charm-metadata']['Name']
    u'wordpress'

You can also get files for the entity::

    >>> cs.files('wordpress')['hooks/install']
    u'https://api.jujucharms.com/v4/wordpress/archive/hooks/install
    >>> hook = cs.files('wordpress', filename='hooks/install', read_file=True)
    >>> print hook
    #!/bin/bash

    set -xe
    ...
    <snipped for length>
    ...
    juju-log "So, environment is setup. We'll wait for some hooks to fire off before we get all crazy"

To see all methods available, refer to the full docs.




History
-------

0.3.8 (2016-11-23)
++++++++++++++++++

Properly quote the user name in the idm query when requesting discharge tokens.

0.3.7 (2016-11-03)
++++++++++++++++++

Supports overriding the default URL for backwards compatibility.
Accept cs: prefix on entity IDs

0.3.6 (2016-10-03)
++++++++++++++++++

Replaces JEM API with JIMM API.

0.3.5 (2016-09-30)
++++++++++++++++++

Discharge for user to return an encoded array.
Update Makefile to work on clean trusty machine.
Trivial rename of development channel.

0.3.4 (2016-07-28)
++++++++++++++++++

Unify timeout.
Make sure we don't have unexpected exception.
Add discharge token for user endpoint.

0.3.3 (2016-07-04)
++++++++++++++++++

Add support case creation.

0.3.2 (2016-06-14)
++++++++++++++++++

Add support for terms and plan.

0.3.1 (2016-05-10)
++++++++++++++++++

Include owner in api call

0.3.0 (2016-05-03)
++++++++++++++++++

Update JEM API calls to version 2.

0.2.2 (2016-04-19)
++++++++++++++++++

Add resources in meta search and resource_url method.

0.2.1 (2016-04-15)
++++++++++++++++++

* Added code for identity manager and juju environment manager APIs
* Updated docs

0.2.0 (2016-03-24)
++++++++++++++++++

* Add LGPL3 license.
* Add optional channel arguments.
* Make deps less strict to work across trusty -> xenial.

0.1.1 (2016-01-25)
++++++++++++++++++

* Use Reference from jujubundlelib as a parameter.
* Add list endpoint.


0.1.0 (2015-12-04)
++++++++++++++++++

* Fix for empty macaroon cookie.


0.0.5 (2015-11-20)
++++++++++++++++++

* Expose common-info.
* Fix import.


0.0.4 (2015-06-10)
++++++++++++++++++

* Support setting a timeout on charmstore requests.


0.0.3 (2015-05-04)
++++++++++++++++++

* Add type filter to charmstore search.


0.0.2 (2015-04-08)
++++++++++++++++++

* Add series filter to charmstore search.
* Handle 407 http error from charmstore as EntityNotFound.
* Add simple usage example to README.
* Minor changes to HACKING.
* Minor fixes.


0.0.1 (2015-03-19)
++++++++++++++++++

* Initial release.


