===============================
Simple DNS resolver for asyncio
===============================

.. image:: https://secure.travis-ci.org/saghul/aiodns.png?branch=master
    :target: http://travis-ci.org/saghul/aiodns

aiodns provides a simple way for doing asynchronous DNS resolutions
with a synchronous looking interface by using `pycares <https://github.com/saghul/pycares>`_.


Example
=======

::

    import asyncio
    import aiodns

    loop = asyncio.get_event_loop()
    resolver = aiodns.DNSResolver(loop=loop)
    f = resolver.query('google.com','A')
    result = loop.run_until_complete(f)
    print(result)


The following query types are supported: A, AAAA, CNAME, MX, NAPTR, NS, PTR, SOA, SRV, TXT.

The library supports both *asyncio* and *Trollius*.

If you use Python 3 you may use `yield from` statement::

    @asyncio.coroutine
    def func():
        result = yield from resolver.query('google.com','A')

For Trollius you should use another syntax like::

    @trollius.coroutine
    def func():
         result = yield trollius.From(resolver.query('google.com','A'))

API
===

The API is pretty simple, three functions are provided in the ``DNSResolver`` class:

* ``query(host, type)``: Do a DNS resolution of the given type for the given hostname. It returns an
  instance of ``asyncio.Future``. The actual result of the DNS query is taken directly from pycares.
  As of version 1.0.0 of aiodns (and pycares, for that matter) results are always namedtuple-like
  objects with different attributes. Please check `the documentation <http://pycares.readthedocs.org/en/latest/channel.html#pycares.Channel.query>`_
  for the result fields.
* ``gethostbyname(host, socket_family)``: Do a DNS resolution for the given
  hostname and the desired type of address family (i.e. ``socket.AF_INET``).
  While ``query()`` always performs a request to a DNS server,
  ``gethostbyname()`` first looks into ``/etc/hosts`` and thus can resolve
  local hostnames (such as ``localhost``).  Please check `the documentation
  <http://pycares.readthedocs.io/en/latest/channel.html#pycares.Channel.gethostbyname>`_
  for the result fields. The actual result of the call is a ``asyncio.Future``.
* ``cancel()``: Cancel all pending DNS queries. All futures will get ``DNSError`` exception set, with
  ``ARES_ECANCELLED`` errno.


Running the test suite
======================

To run the test suite: ``python test_aiodns.py``


Author
======

Saúl Ibarra Corretgé <saghul@gmail.com>


License
=======

aiodns uses the MIT license, check LICENSE file.


Python versions
===============

Python >= 3.4 is natively supported. Python 3.3 supported using the `asyncio package <https://pypi.python.org/pypi/asyncio>`_.
Older Python versions(2.6 - 3.2) are supported using `trollius <https://pypi.python.org/pypi/trollius>`_.


Contributing
============

If you'd like to contribute, fork the project, make a patch and send a pull
request. Have a look at the surrounding code and please, make yours look
alike :-)



