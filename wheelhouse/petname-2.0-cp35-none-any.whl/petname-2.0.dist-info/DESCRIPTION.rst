See: http://pypi.python.org/pypi?name=petname&:action=display_pkginfo


