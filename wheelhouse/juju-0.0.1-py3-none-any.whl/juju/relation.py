import logging

from . import model

log = logging.getLogger(__name__)


class Relation(model.ModelEntity):
    pass
