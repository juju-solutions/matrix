import logging

from . import model

log = logging.getLogger(__name__)


class Annotation(model.ModelEntity):
    pass
