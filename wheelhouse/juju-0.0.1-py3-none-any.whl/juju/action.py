from . import model


class Action(model.ModelEntity):
    pass
